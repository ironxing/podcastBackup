﻿using Podcast.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Podcast.Logic
{
    class KategoriList
    {
        public List<Kategori> List { get; set; }
        
        public List<Kategori> SortedList
        {
            get
            {
                return List.OrderBy((i) => i.Namn).ToList();
            }
        }

        public KategoriList()
        {
            List = new List<Kategori>();
        }
        
        public void Add(Kategori kategori)
        {
            List.Add(kategori);
        }

        public void saveKategori()
        {
            KategoriDB.saveKategori(List);
        }
    }
}
