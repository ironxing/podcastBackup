﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Podcast.Logic
{
    class FeedList
    {
        public List<Feed> List { get; set; }

        public List<Feed> SortedList
        {
            get
            {
                return List.OrderBy((i) => i.Titel).ToList();
            }
        }

        public FeedList()
        {
            List = new List<Feed>();
        }

        public void Add(Feed feed)
        {
            List.Add(feed);
        }

        public void saveFeed()
        {
           // KategoriDB.saveKategori(List);
        }
    }
}

