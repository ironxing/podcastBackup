﻿using Podcast.Logic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;
using System.ServiceModel;
using System.ServiceModel.Description;
using System.ServiceModel.Web;
using System.ServiceModel.Syndication;
using Podcast.Data;


namespace Podcast
{
    public partial class Form1 : Form
    {
       
        KategoriList kategoriList = new KategoriList();
        FeedList feedList = new FeedList();

        public Form1()

        {
            InitializeComponent();
            
        }



        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnNyKategori_Click(object sender, EventArgs e)
        {
            var KategoriNamn = tbKategori.Text;
            Kategori kategori = new Kategori(KategoriNamn);

            if (String.IsNullOrEmpty(KategoriNamn))
            {
                Console.WriteLine("wow");
            }
            else
            {

                kategoriList.Add(kategori);
                uppdateraKategori();
                tbKategori.Clear();
                kategoriList.saveKategori();
                
            }
        }
            

        private void uppdateraKategori()
        {
            lbKategori.Items.Clear();
           

            foreach( var item in kategoriList.SortedList)
            {
                lbKategori.Items.Add(item.Namn);
            }
        }


        private void uppdateraFeedList()
        {
            lvFeed.Items.Clear();
            
            foreach (var item in feedList.SortedList)
            {
                
                var AntalAvsnitt = item.AntalAvsnitt.ToString();
                var Titel = item.Titel.ToString();
                var Frekvens = item.Frekvens.ToString();
                var Kategori = item.Kategori.ToString();

                ListViewItem listitem = new ListViewItem(new[] { AntalAvsnitt, Titel, Frekvens, Kategori });
                lvFeed.Items.Add(listitem);

                

            }
        }

        private void btnNyFeed_Click(object sender, EventArgs e)
        {
            var Url = tbUrl.Text;
            var Frekvens = int.Parse(cbFrekvens.SelectedItem.ToString());
                
                
           
            string Kategori = cbKategori.SelectedItem.ToString();
            

            using (XmlReader reader = XmlReader.Create(Url))
            {

                SyndicationFeed rssFeed = SyndicationFeed.Load(reader);
                int AntalAvsnitt = rssFeed.Items.Count();
                var Titel = rssFeed.Title.Text.ToString();
                Feed feed = new Feed(Titel, AntalAvsnitt, Frekvens, Url, Kategori);




                feedList.Add(feed);
                uppdateraFeedList();
                tbUrl.Clear();
                feedList.saveFeed();
            };

            






            /*
            var feed = new Feed(Url, Frekvens, Kategori);

            FeedList.Add(feed);
            uppdateraFeedList();
            tbUrl.Clear();*/

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            kategoriList.List = KategoriDB.GetKategorier();
            uppdateraKategori();
            uppdateracbKategori();
        
       

            
            /*  XmlReader reader = XmlReader.Create("http://mandag.libsyn.com/rss");
            SyndicationFeed feed = SyndicationFeed.Load(reader);
            reader.Close();

            foreach (SyndicationItem item in feed.Items)
            {
                String subject = item.Title.Text;
                String summary = item.Summary.Text;

            } */

        }

        public void uppdateracbKategori()
        {
            cbKategori.Items.Clear();
            foreach (var item in kategoriList.SortedList)
            {
                cbKategori.Items.Add(item.Namn);
            }
        }

        private void btnAndraKategori_Click(object sender, EventArgs e)
        {
            var kategoriNamnOld = lbKategori.SelectedItem.ToString();
            var kategoriNamnNew = tbKategori.Text;

            if (String.IsNullOrEmpty(kategoriNamnNew))
            {
                Console.WriteLine("wow");
            }
            else
            {
                var kategori = kategoriList.List.FirstOrDefault((i) => i.Namn == kategoriNamnOld);
                kategori.Namn = kategoriNamnNew;
                
                uppdateraKategori();
                tbKategori.Clear();
                kategoriList.saveKategori();
                uppdateracbKategori();
            }
                
            }

            private void selectKategoriItem(object sender, EventArgs e)
            {
                var kategoriNamn = lbKategori.SelectedItem.ToString();
                tbKategori.Text = kategoriNamn;
            }
        private void btnTaBortKategori_Click(object sender, EventArgs e)
        {
            var KategoriNamn = lbKategori.SelectedItem.ToString();

            bool hittad = false;

            while (!hittad)
            {
                for(var i=0; i<kategoriList.List.Count; i++)
                {
                    if (kategoriList.List[i].Namn == KategoriNamn)
                    {
                        hittad = true;
                        kategoriList.List.RemoveAt(i);
                    }
                }
            }

            KategoriDB.saveKategori(kategoriList.List);

            KategoriDB.GetKategorier();

            uppdateraKategori();
            

            

            


        }

        private void cbFrekvens_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
    }
}
